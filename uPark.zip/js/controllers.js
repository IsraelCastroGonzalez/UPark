angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

})
   
.controller('selectedAreaCtrl', function($scope) {

})
   
.controller('areasCtrl', function($scope) {

})
   
.controller('generalCtrl', function($scope) {

})
   
.controller('handicapCtrl', function($scope) {

})
 