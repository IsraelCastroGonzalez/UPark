angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

})
   
.controller('area1Ctrl', function($scope) {

})
   
.controller('areasCtrl', function($scope) {

})
   
.controller('area2Ctrl', function($scope) {

})
   
.controller('generalArea1Ctrl', function($scope) {

})
   
.controller('generalArea2Ctrl', function($scope) {

})
   
.controller('handicapArea1Ctrl', function($scope) {

})
   
.controller('handicapArea2Ctrl', function($scope) {

})
 